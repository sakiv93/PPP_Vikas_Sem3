#----------------------------------Displacement Driven------------------------------------------#
#--------------------------------------27th March-----------------------------------------------#

#-----------------------------------------------------------------------------------------------------------#
#-----------------------------------------------------------------------------------------------------------#
#                               List of variables used                                                      #
#           p,q                     - Degree of the curve in xi and eta direction respectively              #
#           xi,eta                  - Parametric coordinates in xi and eta direction respectively           #
#           ncpxi, ncpeta           - No.of control points in xi and eta direction respectively             #
#           Pw                      - Control points matrix                                                 #
#           Pw_new                  - Deformed Control points matrix (P+U)                                  # 
#           XI, ETA                 - Knot Vectors in xi and eta direction respectively                     #
#           ncp                     - Total number of control points                                        #
#           necp                    - Total number of control points in an element                          # 
#           nel                     - Total number of elements                                              #
#           sigma                   - stress                                                                #
#           Electrical_Displacement - Electrical Displacement                                               #
#           epsilon                 - strain values                                                         #
#           electric_field          - electric field values                                                 #
#           electric_field          - electric field values                                                 #
#           U_g_0                   - Stores final value of DOF's                                           #
#           u_e                     - Stores values of element DOF's                                        #
#           kt_g                    - Global  stiffness matrix                                              #
#           kt_rg                   - Reduced Global  stiffness matrix                                      #
#           K_e                     - Element stiffness matrix                                              #
#           F_g_int                 - Global  internal force matrix                                         #
#           F_e_int                 - Element internal force matrix                                         #
#           F_e_ext                 - Element external force matrix                                         #
#           u_e_indices             - Stores the element DOF numbers                                        #
#-----------------------------------------------------------------------------------------------------------#
#-----------------------------------------------------------------------------------------------------------#
import numpy as np
import matplotlib.pyplot as plt
from pathlib import Path
import sys 
import timeit
import math

stdoutOrigin=sys.stdout 
sys.stdout = open("log.txt", "w")

#-------------------------Initiating Function Counter Variables----------------------------#
# This is done to check number of times a function is called in the analysis.
KnotVector_Count            = 0
FindSpan_Count              = 0
BasisFuns_Count             = 0
DersBasisFuns_Count         = 0
ControlPointAssembly_Count  = 0
materialRoutine_Count       = 0
elementRoutine_Count        = 0
Jacobian12_Count            = 0
B_matrix_Count              = 0
NURBS_Surface_Point_Count   = 0
GaussPoints_Count           = 0
SurfaceDerivsAlgAuv_Count   = 0


            #---------------------------------------------------------------------#
            #                         PreProcessing FUnctions                     #
            #---------------------------------------------------------------------#
#------------------------------------------------------------------------------------------------#
#---------------Knot vector---------------#
def KnotVector(p,n_control_points):
    """
    Input: 
        Input Degree of the NURBS curve (p) 
        and number of control points (n_control_points)
    Process: 
        Function calculates Knot vector array for given 
        Degree and no.of Control points of NURBS Curve
    Return: 
        The function returns knot vector array
    """ 
    global KnotVector_Count
    knot_vector = np.zeros((n_control_points-1)+(p+1)+1)
    for i in range ((n_control_points-1)+(p+1)+1):
        if i<(p+1):
            knot_vector[i]=0
        elif (p+1)<=i<=(n_control_points-1):
            knot_vector[i]=i-(p+1)+1
        else:
            knot_vector[i]=(n_control_points-1)-(p+1)+2
    # To update counter
    KnotVector_Count += 1
    return(knot_vector)
#------------------------------------------------------------------------------------------------#

#------------------------------------------------------------------------------------------------#
#---------------Find Span---------------#
# Function to find knot span in Knot vector
# Example:  If Knot vector = [0,0,1,2,3,4,5] and if xi = 1.5 
#           then knot span is 2 (i.e index of 1 in knot vector) since 1.5 lies between 1 and 2 
def FindSpan(n,p,xi,XI):
    """
    Input: 
        Input [(no.control points-1) - (p+1)] as (n) 
        p of NURBS curve (p),
        Parametric Co-ordinate(xi) on the curve
        knot vector of the curve (XI)
    Process: 
        The function performs linear search for the knot span in knot vector
    Return: 
        The function returns the span of the parametric co-ordinate in the knot vector
    """
    global FindSpan_Count
    FindSpan_Count += 1
    x=XI[p+1]                 # Second Unique knot
    y=XI[-(p+2)]              # Last but one Unique knot
    if (xi < x ):
        return p
    elif (xi>y):
        return (len(XI)-(p+2))
    else:
        for i,pos in enumerate(XI):
            if math.floor(xi) == pos:
                return (i)
#------------------------------------------------------------------------------------------------#

#------------------------------------------------------------------------------------------------#
#-----------------Basis Functions---------------#
# Adapted from alogorithm A2.2 in NURBS Book page no.70
# The output is stored in N[0],....N[p]
# These are non zero functions in a given span
# i is the span of the xi value
# we get N[i-p].........,N[i]
# So if i is 3 then N[3] is stored in N[p] of the output matrix
def BasisFuns(i,xi,p,XI):
    """
    Input: 
        Input knot span (i) of parametric co-ordinate (xi) on NURBS curve
        Degree of the curve (p) and knot vector of the NURBS curve (XI)

    Process: 
        The function find Non-zero basis function and also avoid 
        the occurence of divide by zero
        The output is stored in N[0],....N[p]
        These are non zero functions in a given span
        i is the span of the xi value
        we get N[i-p].........,N[i]
        So if i is 3 then N[3] is stored in N[p] of the output matrix
    Return: 
        The function returns non zero basis functions for the given parametric co-ordinate
    """
    global BasisFuns_Count
    BasisFuns_Count += 1
    N =np.zeros(p+1)
    N[0] = 1.0
    left =np.zeros(p+2)
    right =np.zeros(p+2)
    for j in range(1,p+1):
        left[j] = xi - XI[i+1-j]
        right[j] = XI[i+j] - xi
        saved= 0.0
        for r in range(0,j):
            temp = N[r]/(right[r+1]+left[j-r])
            N[r] = saved + right[r+1]*temp
            saved = left[j-r]*temp
        N[j] = saved
    return N

#-----------------Derivatives of Basis Functions---------------#
# Adapted from alogorithm A2.3 in NURBS Book page no.72
# Derivatives are stored in ders[k][j]
# ders[k][j] is the kth derivative of function N_(i-p+j,p)
# If k>p the derivatives are zero.
def DersBasisFuns(i,xi,p,g,XI):
    """
    Input: 
        Input knot span (i) of parametric co-ordinate (xi) on NURBS curve
        Degree of the curve (p), derivatives upto and including (g) th 
        knot vector of the NURBS curve (XI)

    Process: 
        The function finds Non-zero basis function and also their derivatives
        Derivatives are stored in ders[k][j]
        ders[k][j] is the kth derivative of function N_(i-p+j,p)
        If k>p the derivatives are zero.
    Return: 
        The function returns non zero basis functions and their derivatives
        upto and including mth derivative for the given parametric co-ordinate
    """
    global DersBasisFuns_Count
    DersBasisFuns_Count += 1
    #Inititation of dimentions for 2D matrices
    ndu=np.zeros((p+1,p+1))
    ders=np.zeros((p+1,p+1))
    a=np.zeros((2,p+1))
    left =np.zeros(p+2)
    right =np.zeros(p+2)
    
    ndu[0][0]=1.0
    for j in range(1,p+1):
        left[j] = xi - XI[i+1-j]
        right[j] = XI[i+j] - xi
        saved=0.0
        for r in range(j):
            #Lower triangle
            ndu[j][r] = right[r+1]+left[j-r]
            temp=ndu[r][j-1]/ndu[j][r]
            #Upper triangle
            ndu[r][j] = saved+(right[r+1]*temp)
            saved=left[j-r]*temp
        ndu[j][j] = saved
    for j in range (p+1): #Load the basis functions
        ders[0][j]=ndu[j][p]
    #This secion computes the derivatives
    for r in range(p+1):
        s1=0
        s2=1 #Alternative rows in array a
        a[0][0] = 1.0
        #Loop to compute kth derivative
        for k in range(1,g+1):
            d=0.0
            rk=r-k
            pk=p-k
            if(r>=k):
                a[s2][0]=a[s1][0]/ndu[pk+1][rk]
                d=a[s2][0]*ndu[rk][pk]
            if(rk>=-1):
                j1=1
            else:
                j1=-rk
            if(r-1<=pk):
                j2=k-1
            else:
                j2=p-r
            for j in range (j1,j2+1):
                a[s2][j] =(a[s1][j]-a[s1][j-1])/ndu[pk+1][rk+j]
                d += (a[s2][j]*ndu[rk+j][pk])
            if(r<=pk):
                a[s2][k]=-a[s1][k-1]/ndu[pk+1][r]
                d+=(a[s2][k]*ndu[r][pk])
            ders[k][r]=d
            #Switch rows
            j=s1
            s1=s2
            s2=j
            #Multiply through by the correct factors
    r=p
    for k in range(1,g+1):
        for j in range(p+1):
            ders[k][j] =ders[k][j]* r
        r =r* (p-k)
    return ders

#--------------------------NURBS bivariate basis function derivatives-------------------------------#

#A modified version of Algorithm A3.6 from NURBS Book Page no. 111
#An extra W is given as input to function for convinience which contain weights of corresponding control points
def SurfaceDerivsAlgAuv(n,p,XI,m,q,ETA,P,W,xi,eta,d):
    """
    Input: 
        Input [(no.control points-1) - (p+1)] in xi and eta direction as {n} and {m}
        Degree of the curve in xi and eta direction {p} and {q} respectively
        knot vector of the NURBS curve in xi and eta direction {XI} and {ETA} respectively
        Control point matrix as {P} without weights 
        Weights array {W}
        parametric co-ordinates {xi} and {eta} on NURBS curve in xi and eta direction 
        respectively
        derivatives needed till {d}
    Process: 
        The function will perform derivatives of NURBS bivariate basis functions 
        w.r.t xi and eta
    Return: 
        The function returns two matrices SKL_A and SKL_W

        SKL_A[1][0][0] contains the term (N'_{i,p} N_{j,q}) 
        in the numerator of the equation 16 from documentation

        SKL_A[0][0][0] contains the term (N_{i,p} N_{j,q})  
        in the numerator of the equation 16 from documentation

        SKL_A[0][1][0] contains the term (N_{i,p} N'_{j,q}) 
        in the numerator of the equation 17 from documentation

        SKL_W[0][0] contains the term (W)       :: equation 18 from documentation
        SKL_W[1][0] contains the term (W'_{xi}) :: equation 19 from documentation
        SKL_W[0][1] contains the term (W'_{eta}):: equation 20 from documentation
    """
    global SurfaceDerivsAlgAuv_Count
    SurfaceDerivsAlgAuv_Count += 1
    SKL_A=np.zeros((20,20,3))
    SKL_W=np.zeros((20,20,1))
    temp_A=np.zeros((20,3))
    temp_W=np.zeros((20,1))
    du = min(d,p)
    for k in range(p+1,d+1):
        for l in range(d-k+1):
            SKL_A[k][l]=0.0
            SKL_W[k][l]=0.0
    dv = min(d,q)
    for l in range(q+1,d+1):
        for k in range(d-l+1):
            SKL_A[k][l]=0.0 
            SKL_W[k][l]=0.0 
    xi_span=FindSpan(n,p,xi,XI)
    unders=DersBasisFuns(xi_span,xi,p,du,XI)
    eta_span=FindSpan(m,q,eta,ETA)
    vnders=DersBasisFuns(eta_span,eta,q,dv,ETA)
    for k in range(du+1):
        for s in range(q+1):
            temp_A[s] = 0.0
            temp_W[s] = 0.0
            for r in range(p+1):
                temp_A[s]=temp_A[s] + unders[k][r]*P[xi_span-p+r][eta_span-q+s]*W[xi_span-p+r][eta_span-q+s]
                temp_W[s]=temp_W[s] + unders[k][r]*W[xi_span-p+r][eta_span-q+s]
            dd=min(d-k,dv)
            for l in range(dd+1):
                SKL_A[k][l] = 0.0
                SKL_W[k][l] = 0.0
                for s in range(q+1):
                    SKL_A[k][l] = SKL_A[k][l] + vnders[l][s]*temp_A[s]
                    SKL_W[k][l] = SKL_W[k][l] + vnders[l][s]*temp_W[s]
    return SKL_A,SKL_W

#----------------Point on NURBS Surface---------------------#
def NURBS_Surface_Point(n,p,XI,m,q,ETA,Pw,xi,eta):
    """
    Input: 
        Input [(no.control points-1) - (p+1)] in xi and eta direction as {n} and {m}
        Degree of the curve in xi and eta direction {p} and {q} respectively
        knot vector of the NURBS curve in xi and eta direction {XI} and {ETA} respectively
        Control point matrix as {Pw} 
        parametric co-ordinates {xi} and {eta} on NURBS curve in xi and eta direction 
        respectively
    Process: 
        The function performs tensor product between NURBS basis functions
        in xi and eta directions.
    Return: 
        The function returns physical co-ordinates of the NURBS surface point from the 
        given parametric co-ordinates {xi} and {eta}
    """
    global NURBS_Surface_Point_Count
    NURBS_Surface_Point_Count += 1
    surface_point=np.zeros(3)
    xi_span = FindSpan(n,p,xi,XI)
    Nxi=BasisFuns(xi_span,xi,p,XI)
    eta_span = FindSpan(m,q,eta,ETA)
    Neta=BasisFuns(eta_span,eta,q,ETA)
    S=np.zeros(4)
    for d in range(4):
        Sw=0.0
        for j in range(q+1):
            for i in range(p+1):
                Sw = Sw + Nxi[i]*Neta[j]*Pw[xi_span-p+i][eta_span-q+j][d]
        S[d]=Sw   
    #surface_point=S[:-1]
    surface_point=S[:-1]/S[-1]
    return surface_point

#-----------------------------------Algorithm adopted from -------------------------------------# 
# Vishal Agrawal and Sachin S Gautam. Iga: A simplied introduction and implementation
# details for nite element users. Journal of The Institution of Engineers (India): Series C,
# 100(3):561{585, 2019.

#-----------------Inputs-----------------------#
# n-no.of control points along xi direction
# p-Degree of basis function along xi direction
# m-no.of control points along eta direction
# q-Degree  of basis function along eta direction
def ControlPointAssembly(n,p,m,q,ele_no):
    global ControlPointAssembly_Count
    ControlPointAssembly_Count +=1
    nel= (n-p)*(m-q) 
    ncp= n*m
    necp = (p+1)*(q+1)
    ControlPointAssemblyArray = np.zeros((necp,nel))
    A=0
    e=0
    for j in range(1,m+1):
        for i in range(1,n+1):
            A=A+1
            if (i>=(p+1) and j>=(q+1)):
                e=e+1
                for jloc in range(q+1):
                    for iloc in range(p+1):
                        B=A-jloc*n-iloc
                        b=jloc*(p+1)+iloc+1
                        ControlPointAssemblyArray[b-1,e-1]=B
    CP = np.flip(np.transpose(ControlPointAssemblyArray),axis=1)-1 #To generate data in proper order
    # -1 so that indices will start from '0'
    return  CP[ele_no]
#-----------------------------------------------------------------------------------------------#

            #---------------------------------------------------------------------#
            #                               Geometry                              #
            #---------------------------------------------------------------------#

#------------------------------------Degree of the curve----------------------------------------#
#--------Order of the curve is degree+1
p=1 #Degree of the curve in xi  direction   
q=1 #Degree of the curve in eta direction

#-----------------------------------Dimensions of 2D Plate--------------------------------------#
Thick   = 1.0  #Thickness of the plate in mm
Length  = 10.0 #Length of the plate    in mm
Height  = 10.0 #Height of the plate    in mm

#------------------Number of Control points in xi and eta direction-----------------------------#
#--------Number of control points have to be greater than degree of the curve in respective direction
ncpxi    = 50 # No.of control points in xi  direction
ncpeta   = 50 # No.of control points in eta direction
#----------Need not alter below variables--------------#

# A switch class is implemented inorder to select the gauss points and weights according with 
# degree of the curve in each direction.
class Switcher_Gauss(object):
          def indirect(self,i):
                   method_name='Gauss_'+str(i)
                   method=getattr(self,method_name,lambda :'Invalid')
                   return method()
          def Gauss_0(self):
                   return np.array([[0],[2]])
          def Gauss_1(self):
                   return np.array([[0.5773,-0.5773],[1.0,1.0]])
          def Gauss_2(self):
                   return np.array([[0.7746,-0.7746,0.0],[0.5556,0.5556,0.8889]])
          def Gauss_3(self):
                   return np.array([[0.8611,-0.8611,0.3399,-0.3399],[0.3478, 0.3478,0.6521,0.6521]])

def GaussPoints(p,q):
    global GaussPoints_Count
    GaussPoints_Count += 1
    GaussMatrix=np.zeros(((p+1)*(q+1),3))
    s=Switcher_Gauss()
    GaussPoints_xi  = s.indirect(p)
    GaussPoints_eta = s.indirect(q)
    k=0
    for i in range(p+1):
        for j in range(q+1):
            GaussMatrix[k,0]= GaussPoints_xi[0,i]
            GaussMatrix[k,1]= GaussPoints_eta[0,j]
            GaussMatrix[k,2]= GaussPoints_xi[1,i] * GaussPoints_eta[1,j]
            k+=1       
    return GaussMatrix

GPs_Ws = GaussPoints(p,q) # Gauss points along with their respective weights

p_ord=p+1 #order of the curve in xi direction
q_ord=q+1 #order of the curve in eta direction

d=1         #Derivatives need upto (k+l=d) Only first derivatives are needed for Analysis
nudof = 2   #Number of displacement degrees of freedom on each node
nedof = 1   #Number of electrical degrees of freedom on each node

#-----------------------Calculating Control point matrix----------------------------------#
Pw =np.zeros((ncpeta,ncpxi,4)) 
for j in range(ncpeta):
    for i in range(ncpxi):
        Pw[j,i,0] = (Length/(ncpxi-1))*i
        Pw[j,i,1] = (Height/(ncpeta-1))*j
        Pw[j,i,2] = 0
        Pw[j,i,3] = 1                     # Weights for respective control points


# Input control point vector to element routine as a transpose
Pw_T = Pw.transpose((1,0,2))  #Here it is a 3D array (0,1,2) -- it is transposed to (1,0,2)

XI = KnotVector(p,ncpxi)    # Knot Vector in xi  direction
ETA = KnotVector(q,ncpeta)  # Knot Vector in eta direction)

n=(np.size(XI)-1)-p-1
m=(np.size(ETA)-1)-q-1
P=Pw_T[:,:,0:3]
W=Pw_T[:,:,3]

#**********************************************************************
ncp = ncpxi*ncpeta #Total number of control points

nel= (ncpxi-p)*(ncpeta-q)
necp= (p+1)*(q+1)   #Total number of control points per element
necpxi  = (p+1)     #Number of control points per element along xi  direction
necpeta = (q+1)     #Number of control points per element along eta direction

#------------------------Knot connectivity-----------------------------#

uniqueXI  = np.unique(XI)
uniqueETA = np.unique(ETA)

nelXI  = ncpxi-p
nelETA = ncpeta-q
knotConnectivity = np.zeros((nel,2)) 
Span_XI  = np.zeros((nelXI,2))  # Span_XI have rows equal to number of elements in xi direction
Span_ETA = np.zeros((nelETA,2)) # Span_ETA have rows equal to number of elements in eta direction
count=0

#-----------------------------------Algorithm adopted from -------------------------------------# 
# Vishal Agrawal and Sachin S Gautam. Iga: A simplied introduction and implementation
# details for nite element users. Journal of The Institution of Engineers (India): Series C,
# 100(3):561{585, 2019.

for i in range(0,nelETA):
    for j in range(0,nelXI):
        knotConnectivity[count,:] = [j+1,i+1] 
        # First and second coloumns of 'knotConnectivity' store the global number of knot span ranges
        # or row number of Span_XI and Span_ETA arrays
        Span_XI[j,:]= [uniqueXI[j],uniqueXI[j+1]]
        Span_ETA[i,:]= [uniqueETA[i],uniqueETA[i+1]]
        count=count+1
knotConnectivity = knotConnectivity -1
knotConnectivity = knotConnectivity.astype(int)
#------------------------------------------------------------------------------------------------# 

            #---------------------------------------------------------------------#
            #                           Material Properties                       #
            #---------------------------------------------------------------------#

# A switcher class is used to select the material proprties according to the requirements.
# Three cases are involved 
# Linear Elastic case, Linear Electrical case and Linear Electro-Mechanical case
class Switcher(object):
    def indirect(self,i):
            method_name='LoadCase_'+str(i)
            method=getattr(self,method_name,lambda :'Invalid')
            return method()
    def LoadCase_1(self):
            #---------------------------------------------------------------------#
            #                    Mechanical Case                                  #
            #---------------------------------------------------------------------#

        #----------PZT-PIC151 Material Properties------------#

        #-----------------------Elastic Constants------------------------------#
        Ct = np.array([[110000,64000,0],[64000,100000,0],[0,0,20000]])  #Units MPa

        #---------------Piezoelectric constant matrix-----------------#
        e = np.array([[0,0,0],[0,0,0]])                                 #Units N/Vmm

        #---------------Dielectric material constants-----------------#
        k = np.array([[7.54e-9,0],[0,9.82e-9]])                         #Units N/V^2
        return Ct,e,k


    def LoadCase_2(self):
            #---------------------------------------------------------------------#
            #                    Electrical Case                                  #
            #---------------------------------------------------------------------#

        #----------PZT-PIC151 Material Properties------------#

        #-----------------------Elastic Constants------------------------------#
        Ct = np.array([[110000,64000,0],[64000,100000,0],[0,0,20000]])  #Units MPa

        #---------------Piezoelectric constant matrix-----------------#
        e = np.array([[0,0,0],[0,0,0]])                                 #Units N/Vmm

        #---------------Dielectric material constants-----------------#
        k = np.array([[7.54e-9,0],[0,9.82e-9]])                         #Units N/V^2
        return Ct,e,k


    def LoadCase_3(self):
            #---------------------------------------------------------------------#
            #                    Electro Mechanical Case                          #
            #---------------------------------------------------------------------#

        #----------PZT-PIC151 Material Properties------------#

        #-----------------------Elastic Constants------------------------------#
        Ct = np.array([[110000.,64000.,0.],[64000.,100000.,0.],[0.,0.,20000.]])     #Units MPa

        #---------------Piezoelectric constant matrix-----------------#
        e = np.array([[0.,0.,12.0e-3],[-9.6e-3,15.1e-3,0.]])                        #Units N/Vmm

        #---------------Dielectric material constants-----------------#
        k = np.array([[7.54e-9,0],[0,9.82e-9]])                                     #Units N/V^2
        return Ct,e,k


# Can select the below parameter according to the test case requirement
#   1 - Linear Elastic Loading
#   2 - Linear Electrical Loading
#   3 - Linear Electro-Mechanical Loading
LoadCaseNumber = 3

s=Switcher()
Ct,e,k  = s.indirect(LoadCaseNumber)

            #---------------------------------------------------------------------#
            #                        Boundary Conditions                          #
            #---------------------------------------------------------------------#

#Initializing global displcement vector
U_g_0=np.zeros(((nudof+nedof)*ncp,1))

# The following code isolates Degrees of freedom numbers of nodes 
# for easily handling bounday conditions (BCS) definition. 

#-------------Bottom nodes Y displacement Dof----------------#
Bottom_nodes_u = np.zeros(ncpxi)
for BNu in range(ncpxi):
    Bottom_nodes_u[BNu] =2*BNu+1
Bottom_nodes_u= Bottom_nodes_u.astype(int)

#-------------Left nodes X displacement Dof------------------#
Left_nodes_u = np.zeros(ncpeta)
for LNu in range(ncpeta):
    Left_nodes_u[LNu] = (ncpxi*2)*LNu
Left_nodes_u= Left_nodes_u.astype(int)

#-------------Right nodes X displacement  Dof------------------#
Right_nodes_u = np.zeros(ncpeta)
for RNu in range(ncpeta):
    Right_nodes_u[RNu] = ((ncpxi*2)*RNu) + (ncpxi-1)*2
Right_nodes_u= Right_nodes_u.astype(int)

#-------------Top nodes Y displacement Dof----------------#
Top_nodes_u = np.zeros(ncpxi)
for TNu in range(ncpxi):
    Top_nodes_u[TNu] =((ncpxi*2) * (ncpeta-1) + 1) + (TNu*2)
Top_nodes_u= Top_nodes_u.astype(int)

#-------------Left nodes Electric Dof------------------#
Left_nodes_e = np.zeros(ncpeta)
for LNe in range(ncpeta):
    Left_nodes_e[LNe] = ncpxi*ncpeta*2 + ncpxi*LNe
Left_nodes_e= Left_nodes_e.astype(int)

#-------------Right nodes Electric Dof------------------#
Right_nodes_e = np.zeros(ncpeta)
for RNe in range(ncpeta):
    Right_nodes_e[RNe] = (ncpxi*ncpeta*2 -1) + ncpxi*(RNe+1)
Right_nodes_e= Right_nodes_e.astype(int)

#---------------Top nodes Electric Dof-------------------#
Top_nodes_e = np.zeros(ncpxi)
for TNe in range(ncpxi):
    Top_nodes_e[TNe] = ncpxi*ncpeta*2 + ncpxi*(ncpeta-1) +TNe
Top_nodes_e= Top_nodes_e.astype(int)

#-------------Bottom nodes Electric Dof------------------#
Bottom_nodes_e = np.zeros(ncpxi)
for BNe in range(ncpxi):
    Bottom_nodes_e[BNe] = ncpxi*ncpeta*2 + BNe
Bottom_nodes_e= Bottom_nodes_e.astype(int)

#---------------------Boundary Conditions definition-------------------------#

#-------------Displacement Loading-------------#
U_g_0[Right_nodes_u]  = 1e-4
U_g_0[Top_nodes_u]    = 2e-4

#---------------Fixed Displacement BCS---------------#
U_g_0[Bottom_nodes_u] = 0
U_g_0[Left_nodes_u]   = 0

#----------------Grounded Electrical BCS----------------#
U_g_0[Top_nodes_e]    = 0

#----------------Electrical Loading----------------#
#U_g_0[Bottom_nodes_e]  = 100

#-------------Replace this every time for defining BCS in main program-----------------------#
# Or direct node numbers can be given where boundary conditions for DOF are given 
# Format [2,10,3] (Example : DOF numbers inside an list)
BCS=np.sort(np.concatenate((Right_nodes_u,Top_nodes_u,Bottom_nodes_u,Left_nodes_u,Top_nodes_e)))

            #---------------------------------------------------------------------#
            #                           Material Routine                          #
            #---------------------------------------------------------------------#

def materialRoutine(epsilon,electric_field, T_m):
    global materialRoutine_Count
    materialRoutine_Count += 1
    """
    Input: 
        Input strain data(epsilon), Electric field data(electric_field) from element routine
    Process: 
        Material routine calculates Element tangent stiffness matrix 
        (Elastic (Ct), Piezoelectric (e) and dielectric constants (k))
        Stress (Sigma) and Electrical displacements (Electrical_Displacement) 
        are also calculated.
    Return: 
        The function returns Elastic, Piezoelectric, dielectric constant matrices, 
        Stress and Electrical displacements 
    """

    # Calculating stress and electrical displacements
    sigma  = np.matmul(Ct,epsilon)-np.matmul(np.transpose(e),electric_field)
    Electrical_Displacement = np.matmul(e,epsilon)+np.matmul(k,electric_field)


    # Returning Elastic,Piezoelectric, Dielectric constants, Stress and Electrical Displacements
    return Ct, e, k, sigma, Electrical_Displacement

            #---------------------------------------------------------------------#
            #                               Element Routine                       #
            #---------------------------------------------------------------------#

def Jacobian12(xi,eta,elXI,elETA):
    """
    Input: 
        Input Parametric Co-ordinates (xi,eta) of Gauss Points
        ***Gauss Co-ordinates are defined in master space***
        Knot span range (elXI,elETA) in xi and eta direction
    Process: 
        Inputs functions involving partial derivatives of NURBS Basis Functions
        w.r.t to parametric co-ordinates and Calculates J1 matrix
    Return: 
        The function returns J1 and determinant of J1 and J2 matrix
    """
    global Jacobian12_Count
    Jacobian12_Count += 1
    #------------Calculating J1-------------------------#
    # J1 matrix for mapping from paramteric space to physical space.

    dxi_dximas = 0.5*(elXI[1]-elXI[0])          # Refer Equation 25 from Documentation
    deta_detamas = 0.5*(elETA[1]-elETA[0])      # Refer Equation 26 from Documentation 
    J2det = dxi_dximas*deta_detamas

    #------------Calculating J2-------------------------#
    # J2 matrix for mapping from master space to parametric space.

    #--------Evaluation of NURBS Surface basis functions derivatives---------#
    Aders,wders = SurfaceDerivsAlgAuv(n,p,XI,m,q,ETA,P,W,xi,eta,d)

    #-----------------------------------------------------------------------------------------------
    dRx_dxi     = (Aders[1][0][0]*wders[0][0] - wders[1][0]*Aders[0][0][0])/(wders[0][0]*wders[0][0])
    dRy_dxi     = (Aders[1][0][1]*wders[0][0] - wders[1][0]*Aders[0][0][1])/(wders[0][0]*wders[0][0])
    dRx_deta    = (Aders[0][1][0]*wders[0][0] - wders[0][1]*Aders[0][0][0])/(wders[0][0]*wders[0][0])
    dRy_deta    = (Aders[0][1][1]*wders[0][0] - wders[0][1]*Aders[0][0][1])/(wders[0][0]*wders[0][0])
    J1 = np.array([[dRx_dxi[0],dRx_deta[0]],
                [dRy_dxi[0],dRy_deta[0]]])

    J1det = (dRx_dxi[0]*dRy_deta[0])-(dRx_deta[0]*dRy_dxi[0])
    J1inv = np.linalg.inv(J1)
    return J1,J1det,J2det

def B_matrix(xi,eta,J1):
    """
    Input: 
        Input Parametric Co-ordinates (xi,eta) of Gauss Points
        ***Gauss Co-ordinates are defined in master space***
    Process: 
        Calls function to find derivatives of NURBS Basis functions
        and Store the values in Bu matrix (B matrix related to mechanical case)
        and Be matrix (B matrix related to electrical case)
    Return: 
        The function returns Bu matrix and Be matrix
    """
    global B_matrix_Count
    B_matrix_Count += 1

    Bu=np.zeros((3,nudof*necp))
    Be=np.zeros((2,necp))
    #---------------NURBS Basis Functions Derivatives wrt x and y-------------#
    xi_span = FindSpan(n,p,xi,XI)
    eta_span = FindSpan(m,q,eta,ETA)
    # Indices of non vanishing basis functions
    NVxi = np.arange(xi_span-p,xi_span+1,1)
    NVeta = np.arange(eta_span-q,eta_span+1,1)
    Aders,wders = SurfaceDerivsAlgAuv(n,p,XI,m,q,ETA,P,W,xi,eta,d)
    Denom = wders[0][0]
    Denom_du = wders[1][0]
    Denom_dv = wders[0][1]

    dR_dx = np.zeros((necpxi,necpeta))
    dR_dy = np.zeros((necpxi,necpeta))
    #---------------Loop over Non vanishing NURBS Basis Functions-------------#
    for ii, ii_value in enumerate(NVxi):
        for jj, jj_value in enumerate(NVeta):
            BFxi = BasisFuns(xi_span,xi,p,XI)
            BFeta = BasisFuns(eta_span,eta,q,ETA)
            Num = BFxi[ii]*BFeta[jj]**W[ii][jj]
            DBFxi = DersBasisFuns(xi_span,xi,p,d,XI)
            DBFeta = DersBasisFuns(eta_span,eta,q,d,ETA)
            Num_dxi = DBFxi[1][ii]*BFeta[jj]*W[ii][jj]
            Num_deta = BFxi[ii]*DBFeta[1][jj]*W[ii][jj]
            dR_dxi = Num_dxi/Denom - Denom_du*Num/(Denom*Denom)
            dR_deta = Num_deta/Denom - Denom_dv*Num/(Denom*Denom) 

            dR_dxi_dR_deta = np.array([dR_dxi,dR_deta])
            dR_dx_dR_dy = np.matmul(np.linalg.inv(J1),dR_dxi_dR_deta)
            dR_dx[ii][jj] = dR_dx_dR_dy[0]
            dR_dy[ii][jj] = dR_dx_dR_dy[1]
    #-------------Have to multiply dR_dx / dR_dy matrix with jacobian matrix-------------------#

    #---------Flatten (Convert 2D to 1D array) DervsNURBS Function------------#
    #dR_dx(0,0)....dR_dx(0,1),dR_dx(1,0),.....dR_dx(1,4).....dR_dx(4,0),..........dR_dx(4,4)
    fdR_dx = (np.transpose(dR_dx)).flatten()
    fdR_dy = (np.transpose(dR_dy)).flatten()
    #-------------------------Bu Matrix --------------------------#
    for i2 in range(necp):
        j1= 2*i2
        j2= 2*i2+1
        Bu[0,j1] = fdR_dx[i2]
        Bu[1,j2] = fdR_dy[i2]
        Bu[2,j1] = fdR_dy[i2]
        Bu[2,j2] = fdR_dx[i2]

        Be[0,i2] = fdR_dx[i2]
        Be[1,i2] = fdR_dy[i2]
    return Bu,Be

def elementRoutine(U_e,elXI,elETA,T_m):
    """
    Input: 
        Input (U_e) matrix which contain DOF values 
        Knot span range (elXI,elETA) in xi and eta direction
    Process: 
        The element routine takes in information about the element 
        and loops over gauss points and perform numerical integration
        to find the values of Internal and External force matrix,
        Elemental stiffness matrix.
    Return: 
        The function returns Elemental Stiffness matrix (Kt_e), 
        Internal and External elemental force matrix, 
        Stress,Strain,Electric field and Electric displacements at Gauss points
    """
    global elementRoutine_Count
    elementRoutine_Count += 1
    Kt_e = np.zeros(((nudof+nedof)*necp,(nudof+nedof)*necp))            # Element stiffness matrix
    K_MM=np.zeros((nudof*necp,nudof*necp))                              # Refer Equation 56 from Documentation
    K_ME=np.zeros((nudof*necp,nedof*necp))                              # Refer Equation 57 from Documentation
    K_EM=np.zeros((nedof*necp,nudof*necp))                              # Refer Equation 58 from Documentation
    K_EE=np.zeros((nedof*necp,nedof*necp))                              # Refer Equation 59 from Documentation
    Fu_int_e=np.zeros((nudof*necp,1))                                   # Internal force matrix (Mechanical)
    Fe_int_e=np.zeros((nedof*necp,1))                                   # Internal force matrix (Electrical)
    F_int_e=np.zeros(((nudof+nedof)*necp,1))                            # Internal force matrix
    sigma_ig=np.zeros((np.shape(GPs_Ws)[0],3,1))                        # Stress matrix to store values at each gauss point
    epsilon_ig=np.zeros((np.shape(GPs_Ws)[0],3,1))                      # Strain matrix to store values at each gauss point
    electric_field_ig = np.zeros((np.shape(GPs_Ws)[0],2,1))             # Electrical field matrix to store values at each gauss point
    Electrical_Displacement_ig = np.zeros((np.shape(GPs_Ws)[0],2,1))    # Electrical displacement matrix to store values at each gauss point

    #-----------Looping over gauss point-----------#

    for j in range(np.shape(GPs_Ws)[0]):

        gp = GPs_Ws[j,0:2]      # For fetching respective gauss points
        wg = GPs_Ws[j,2]        # For fetching respective gauss point weights
        ximas = gp[0]       # Gauss points in Master space
        etamas = gp[1]      # Gauss points in Master space
        xi = 0.5*((elXI[1]-elXI[0])*ximas + (elXI[1]+elXI[0]))          # Gauss points in Parametric space
        eta = 0.5*((elETA[1]-elETA[0])*etamas + (elETA[1]+elETA[0]))    # Gauss points in Parametric space

        #------Calling Jacobian12 Function to get J1 and J2 determinants-----------#

        J1,J1det,J2det = Jacobian12(xi,eta,elXI,elETA)

        #-----------------Calling B_matrix function for Bu and Be Matrix--------------------#
        #-------Bu::(B matrix for mechanical case) Be::(B matrix for electrical case) ------#

        Bumatrix,Bematrix = B_matrix(xi,eta,J1)

        # U_u contains mechanical displcement from control point 1 to total control points in the element
        # U_phi contains electric potential from control point 1 to total control points in the element
        U_u=U_e[0:necp*nudof]
        U_phi = U_e[necp*nudof:]

        epsilon = np.matmul(Bumatrix,U_u)               # Strain
        electric_field = -np.matmul(Bematrix,U_phi)     # Electric_field
        epsilon_ig[j]=epsilon                   #Storing value of Strain at each gauss point
        electric_field_ig[j] = electric_field   #Storing value of electric_field at each gauss point

        #-----------------------Calling Matrial Routine----------------------#

        C, e, k, sigma, Electrical_Displacement = materialRoutine(epsilon,electric_field, T_m)
        #-----Storing value of Stress at each gauss point
        sigma_ig[j] = sigma 
        #-----Storing value of Electrical Displacement at each gauss point                                   
        Electrical_Displacement_ig[j] = Electrical_Displacement
        #-------------------------Local Stiffness matrix Ke-------------------#
        CBu=np.matmul(C,Bumatrix)
        BuCBu = np.matmul(np.transpose(Bumatrix),CBu)

        eBe=np.matmul(np.transpose(e),Bematrix)
        BueBe=np.matmul(np.transpose(Bumatrix),eBe)

        eBu=np.matmul(e,Bumatrix)
        BeeBu = np.matmul(np.transpose(Bematrix),eBu)

        kBe=np.matmul(k,Bematrix)
        BekBe = np.matmul(np.transpose(Bematrix),kBe)

        #------------------Numerical Integration-----------------------#

        K_MM = K_MM + BuCBu*J1det*J2det*wg*Thick
        K_ME = K_ME + BueBe*J1det*J2det*wg*Thick
        K_EM = K_EM + BeeBu*J1det*J2det*wg*Thick
        K_EE = K_EE - BekBe*J1det*J2det*wg*Thick

        #Arranging to Kt_e matrix (Local element Stiffness matrix)
        #    Kt_e = [K_MM K_ME]         # Refer Equation 55 from Documentation
        #           [K_EM K_EE]
        Kt_e[0:necp*nudof,0:necp*nudof]                                     = K_MM
        Kt_e[0:necp*nudof,necp*nudof:necp*(nudof+nedof)]                    = K_ME
        Kt_e[necp*nudof:necp*(nudof+nedof),0:necp*nudof]                    = K_EM
        Kt_e[necp*nudof:necp*(nudof+nedof),necp*nudof:necp*(nudof+nedof)]   = K_EE

        #------------Internal Force calculations--------------------#

        #-------Internal Force calculation for Mechanical case
        Fu_int_e= Fu_int_e+np.matmul(np.transpose(Bumatrix),sigma)*J1det*J2det*wg*Thick
        #-------Internal Force calculation for Electrical case
        Fe_int_e= Fe_int_e+np.matmul(np.transpose(Bematrix),Electrical_Displacement)*J1det*J2det*wg*Thick

        # ------Arranging to local Force_internal matrix 
        F_int_e[0:nudof*necp] = Fu_int_e                              # 0 1 2 3 .... 2*ncep-2, 2*ncep-1
        F_int_e[nudof*necp:(nudof*necp+nedof*necp)] = Fe_int_e        # 2*ncep, 2*ncep+1 .......  2*ncep+(ncep-1)
        #-------Initiating Force External as zero array because of displacement driven algorithm  
        F_ext_e = np.zeros_like(F_int_e)    
    return Kt_e, F_int_e, F_ext_e, sigma_ig, Electrical_Displacement_ig,epsilon_ig,electric_field_ig

            #---------------------------------------------------------------------#
            #                            Main Program                             #
            #---------------------------------------------------------------------#

start = timeit.timeit()
for i in range(1):
    tau = 1
    u_g = U_g_0
    
    #------------------DO Newton_Raphson_method----------------------------#
    Newton=1
    while 1:
        #-----------Initializing------------# 
        Kt_g=np.zeros([(nudof+nedof)*ncp,(nudof+nedof)*ncp])    # Global Stiffness matrix 
        G_global=np.zeros(((nudof+nedof)*ncp,1))                # Global G (G = F_int-F_ext)

        #First 2*ncp rows are mechanical forces next 4 rows are electrical forces in each element 
        F_g_int=np.zeros(((nudof+nedof)*ncp,1))                 # Global Force internal

        #--------Looping over elements in the simulation----------# 
        for j in range(nel):
            # Fetching indices of displacement DOF in an element.
            u_e_indices=ControlPointAssembly(ncpxi,p,ncpeta,q,j)

            # Generated values of 'u_e_indices' are of float. 
            # Converting to int for using it as indices of array
            u_e_indices = u_e_indices.astype(int)
            u_e_indices = np.concatenate((nudof*u_e_indices+0,nudof*u_e_indices+1,(ncp*nudof)+u_e_indices))
            u_e_indices=np.sort(u_e_indices)
            u_e = u_g[u_e_indices]

            #------ Extracting values of the knot span for the element in each direction
            elXI =  Span_XI[knotConnectivity[j,0]]
            elETA = Span_ETA[knotConnectivity[j,1]]

            #--------------------Calling Element Routine------------------------------#
            K_e,F_e_int,F_e_ext,sigma,Electrical_Displacement,epsilon,electric_field = elementRoutine(u_e,elXI,elETA,tau)

            F_e_indices = u_e_indices # Already sorted

            #------------For loops to connect local stiffness matrix to global stiffness matrix------------#
            for val1,index1 in enumerate(u_e_indices):
                #print('Connecticity outer loop:',val1,index1)
                for val2,index2 in enumerate(u_e_indices):
                    #print('Connecticity inner loop:',val2,index2)
                    Kt_g[index1,index2] = Kt_g[index1,index2] +K_e[val1,val2]
            G_global[F_e_indices] = G_global[F_e_indices]+(F_e_int-F_e_ext)
            F_g_int[F_e_indices] = F_g_int[F_e_indices]+F_e_int
        ElementLoop_end = timeit.timeit()
        #--------End of Looping over elements in the simulation----------#
        
        #-----------------Reduced system of equations---------------------#
        Kt_rg=Kt_g                           # Kt_rg reduced global stiffness matrix

        #-------------Data from Bounday_Load_Conditions File--------------#
        #--------------------------------BCS------------------------------#
        #BCS:: An Array which is used to delete Global Stiffness matrix rows and coloumns
        #      for solving the equations
        Kt_rg=np.delete(Kt_rg,BCS,axis=0) #axis=0 is row
        Kt_rg=np.delete(Kt_rg,BCS,axis=1)
        reduced_G_global=G_global
        reduced_G_global=np.delete(reduced_G_global,BCS,axis=0)
        dU_g=np.matmul(np.linalg.inv(Kt_rg),-reduced_G_global)

        #-------For Newton Raphson Scheme covergence Criterion--------------#
        dU_g_convergence=dU_g
        u_g_convergence=np.delete(u_g,BCS,axis=0)
        dU_g_insert=dU_g
        #----dU_g_insert matrix is inserted with Boundary and Load conditions nodal values as 0------#
        for val in BCS:
            dU_g_insert=np.insert(dU_g_insert,val,0,axis=0)
        u_g=u_g+dU_g_insert

        if (np.linalg.norm(reduced_G_global,np.inf)<0.005*np.linalg.norm(F_g_int,np.inf) or np.linalg.norm(dU_g_convergence,np.inf)<0.005*np.linalg.norm(u_g_convergence,np.inf) or Newton > 5) :     
            break
        else:
            Newton=Newton+1
    #------------------End of "DO Newton_Raphson_method"----------------------------#
    if Newton>5:
        print("Convergence criterion is not met, at load (peercentage):",tau*100)
        break
    else:
        U_g_0 = u_g


            #---------------------------------------------------------------------#
            #                               TimeIt                                #
            #---------------------------------------------------------------------#

#Timeit is used to compute the time taken by each function in the code.
#------------------------------KnotVector------------------------------#
print('"KnotVector" Fucntion is called for',KnotVector_Count,'times.')
SetUpCode = '''from __main__ import KnotVector
import numpy as np'''
TestCode = '''KnotVector(2,10)'''
print('Time taken for single time function execution: ',timeit.timeit(setup = SetUpCode, 
                stmt = TestCode, 
                number = 1))
print('Total time taken by the function in complete analysis: ',timeit.timeit(setup = SetUpCode, 
                stmt = TestCode, 
                number = KnotVector_Count))
print('\n')
#------------------------------------------------------------------#

#------------------------------FindSpan------------------------------#
print('"FindSpan" Fucntion is called for',FindSpan_Count  ,'times.')
SetUpCode = '''from __main__ import FindSpan
import numpy as np
import math'''
TestCode = '''FindSpan(9,2,3.5,[0., 0., 0., 1., 2., 3., 4., 5., 6., 7., 8., 8., 8.])'''
print('Time taken for single time function execution: ',timeit.timeit(setup = SetUpCode, 
                stmt = TestCode, 
                number = 1))
print('Total time taken by the function in complete analysis: ',timeit.timeit(setup = SetUpCode, 
                stmt = TestCode, 
                number = FindSpan_Count))
print('\n')
#------------------------------------------------------------------#

#------------------------------BasisFuns------------------------------#
print('"BasisFuns" Fucntion is called for',BasisFuns_Count,'times.')
SetUpCode = '''from __main__ import BasisFuns
import numpy as np'''
TestCode = '''BasisFuns(5,3.5,2,[0., 0., 0., 1., 2., 3., 4., 5., 6., 7., 8., 8., 8.])'''
print('Time taken for single time function execution: ',timeit.timeit(setup = SetUpCode, 
                stmt = TestCode, 
                number = 1))
print('Total time taken by the function in complete analysis: ',timeit.timeit(setup = SetUpCode, 
                stmt = TestCode, 
                number = BasisFuns_Count))
print('\n')
#------------------------------------------------------------------#

#------------------------------DersBasisFuns------------------------------#
print('"DersBasisFuns" Fucntion is called for',DersBasisFuns_Count,'times.')
SetUpCode = '''from __main__ import DersBasisFuns
import numpy as np'''
TestCode = '''DersBasisFuns(5,3.5,2,1,[0., 0., 0., 1., 2., 3., 4., 5., 6., 7., 8., 8., 8.])'''
print('Time taken for single time function execution: ',timeit.timeit(setup = SetUpCode, 
                stmt = TestCode, 
                number = 1))
print('Total time taken by the function in complete analysis: ',timeit.timeit(setup = SetUpCode, 
                stmt = TestCode, 
                number = DersBasisFuns_Count))
print('\n')
#------------------------------------------------------------------#


#------------------------------ControlPointAssembly------------------------------#
print('"ControlPointAssembly" Fucntion is called for',ControlPointAssembly_Count,'times.')
SetUpCode = '''from __main__ import ControlPointAssembly
import numpy as np'''
TestCode = '''ControlPointAssembly(4,2,4,2,1)'''
print('Time taken for single time function execution: ',timeit.timeit(setup = SetUpCode, 
                stmt = TestCode, 
                number = 1))
print('Total time taken by the function in complete analysis: ',timeit.timeit(setup = SetUpCode, 
                stmt = TestCode, 
                number = ControlPointAssembly_Count))
print('\n')
#------------------------------------------------------------------#

#------------------------------materialRoutine------------------------------#
print('"materialRoutine" Fucntion is called for',materialRoutine_Count,'times.')
SetUpCode = '''from __main__ import materialRoutine
import numpy as np'''
TestCode = '''materialRoutine([[1.e-05],[2.e-05],[0.e+00]],[[0.],[0.]], 1)'''
print('Time taken for single time function execution: ',timeit.timeit(setup = SetUpCode, 
                stmt = TestCode, 
                number = 1))
print('Total time taken by the function in complete analysis: ',timeit.timeit(setup = SetUpCode, 
                stmt = TestCode, 
                number =materialRoutine_Count))
print('\n')
#------------------------------------------------------------------#

#------------------------------elementRoutine------------------------------#
print('"elementRoutine" Fucntion is called for',elementRoutine_Count,'times.')
SetUpCode = '''from __main__ import elementRoutine
import numpy as np'''
TestCode = '''elementRoutine([[0.    ],[0.    ],[0.0001], [0.    ],[0.    ],[0.0002],[0.0001],
[0.0002],[0.    ],[0.    ],[0.    ],[0.    ]],[0., 1.],[0., 1.],1)'''
print('Time taken for single time function execution: ',timeit.timeit(setup = SetUpCode, 
                stmt = TestCode, 
                number = 1))
print('Total time taken by the function in complete analysis: ',timeit.timeit(setup = SetUpCode, 
                stmt = TestCode, 
                number = elementRoutine_Count))
print('\n')
#------------------------------------------------------------------#

#------------------------------Jacobian12------------------------------#
print('"Jacobian12" Fucntion is called for',Jacobian12_Count,'times.')
SetUpCode = '''from __main__ import Jacobian12
import numpy as np'''
TestCode = '''Jacobian12(0.7886500000000001, 0.21134999999999998,[0., 1.],[0., 1.])'''
print('Time taken for single time function execution: ',timeit.timeit(setup = SetUpCode, 
                stmt = TestCode, 
                number = 1))
print('Total time taken by the function in complete analysis: ',timeit.timeit(setup = SetUpCode, 
                stmt = TestCode, 
                number = Jacobian12_Count))
print('\n')
#------------------------------------------------------------------#

#------------------------------B_matrix------------------------------#
print('"B_matrix" Fucntion is called for',B_matrix_Count,'times.')
SetUpCode = '''from __main__ import B_matrix
import numpy as np'''
TestCode = '''B_matrix(0.7886500000000001, 0.21134999999999998,[[10.,  0.],[ 0., 10.]])'''
print('Time taken for single time function execution: ',timeit.timeit(setup = SetUpCode, 
                stmt = TestCode, 
                number = 1))
print('Total time taken by the function in complete analysis: ',timeit.timeit(setup = SetUpCode, 
                stmt = TestCode, 
                number = B_matrix_Count))
print('\n')
#------------------------------------------------------------------#

#------------------------------NURBS_Surface_Point------------------------------#
print('"NURBS_Surface_Point" Function is called for',NURBS_Surface_Point_Count,'times.')
SetUpCode = '''from __main__ import NURBS_Surface_Point
import numpy as np'''
TestCode = '''NURBS_Surface_Point(1, 1, [0., 0., 1., 1.], 1, 1, [0., 0., 1., 1.],
 [[[ 0.    ,  0.    ,  0.    ,  1.    ],[ 0.    , 10.0002,  0.    ,  1.    ]],
 [[10.0001,  0.    ,  0.    ,  1.    ],[10.0001, 10.0002,  0.    ,  1.    ]]], 0.0, 0.0)'''
print('Time taken for single time function execution: ',timeit.timeit(setup = SetUpCode, 
                stmt = TestCode, 
                number = 1))
print('Total time taken by the function in complete analysis: ',timeit.timeit(setup = SetUpCode, 
                stmt = TestCode, 
                number = NURBS_Surface_Point_Count))
print('\n')
#------------------------------------------------------------------#

#------------------------------Timeit------------------------------#
print('"SurfaceDerivsAlgAuv" Function is called for',SurfaceDerivsAlgAuv_Count,'time.')
SetUpCode = '''from __main__ import SurfaceDerivsAlgAuv
import numpy as np'''
TestCode = '''SurfaceDerivsAlgAuv(1, 1, np.array([0., 0., 1., 1.]), 1, 1, np.array([0., 0., 1., 1.]), np.array([[[ 0.,  0.,  0.],
[ 0., 10.,  0.]],[[10.,  0.,  0.],[10., 10.,  0.]]]), np.array([[1., 1.],[1., 1.]]),
0.7886500000000001, 0.7886500000000001, 1)'''
print('Time taken for single time function execution: ',timeit.timeit(setup = SetUpCode, 
                stmt = TestCode, 
                number = 1))
print('Total time taken by the function in complete analysis: ',timeit.timeit(setup = SetUpCode, 
                stmt = TestCode, 
                number = SurfaceDerivsAlgAuv_Count))
print('\n')
#------------------------------------------------------------------#

#------------------------------GaussPoints------------------------------#
print('"GaussPoints" Function is called for',GaussPoints_Count,'time.')
SetUpCode = '''from __main__ import GaussPoints
import numpy as np'''
TestCode = '''GaussPoints(1,1)'''
print('Time taken for single time function execution: ',timeit.timeit(setup = SetUpCode, 
                stmt = TestCode, 
                number = 1))
print('Total time taken by the function in complete analysis: ',timeit.timeit(setup = SetUpCode, 
                stmt = TestCode, 
                number = GaussPoints_Count))
print('\n')
#------------------------------------------------------------------#



end = timeit.timeit()
sys.stdout.close()
sys.stdout=stdoutOrigin